// Cart count
let cartCount = 0;
document.querySelectorAll('.add-to-cart').forEach(button => {
  button.addEventListener('click', () => {
    cartCount++;
    document.getElementById('cart-count').textContent = cartCount;
  });
});

// Search function
const searchInput = document.getElementById('search');

searchInput.addEventListener('keyup', function () {
  let filter = this.value.toLowerCase();

  document.querySelectorAll('.product').forEach(function (item) {
    let name = item.querySelector('h3').textContent.toLowerCase();

    if (filter === "") {
      item.style.display = "";
    } else {
      item.style.display = name.includes(filter) ? "" : "none";
    }
  });
});
let cart = [];
const cartCount = document.querySelector('.cart-count');
const buttons = document.querySelectorAll('button');

buttons.forEach((btn) => {
    btn.addEventListener('click', () => {
        const product = btn.parentElement.querySelector('h2').innerText;
        cart.push(product);
        alert(`product added to cart.`);
        cartCount.textContent = `({cart.length})`;
    });
});
